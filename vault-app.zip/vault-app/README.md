# Bóveda Digital

Aplicación de autocontrol emocional y gestión de información sensible. Diseñada para **reducir accesos impulsivos** a contenido protegido.

## 🧠 Funcionalidad Clave
- Login/registro con validación de contraseña segura
- Configuración de preguntas personales y mensajes disuasorios
- Temporizador de espera entre accesos (minutos, horas, días)
- Registro de actividad persistente
- Diseño seguro, minimalista y moderno

## 📁 Estructura
